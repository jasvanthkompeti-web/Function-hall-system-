CREATE DATABASE IF NOT EXISTS function_hall;
USE function_hall;
-- BookingServer.java creates these automatically too.
-- Run this file if your trainer wants a visible SQL script.