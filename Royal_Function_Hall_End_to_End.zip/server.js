const http=require("http"),fs=require("fs"),path=require("path");
const JAVA="http://localhost:8080";
const root=__dirname;
const types={".html":"text/html",".css":"text/css",".js":"text/javascript",".json":"application/json",".png":"image/png",".jpg":"image/jpeg",".ico":"image/x-icon"};
function proxy(req,res){
 let body=[];req.on("data",d=>body.push(d));req.on("end",()=>{
  const data=Buffer.concat(body);
  const u=new URL(JAVA+req.url);
  const r=http.request({hostname:u.hostname,port:u.port,path:u.pathname+u.search,method:req.method,headers:{"Content-Type":req.headers["content-type"]||"application/json","Content-Length":data.length}},x=>{
   res.writeHead(x.statusCode,{"Content-Type":x.headers["content-type"]||"application/json","Access-Control-Allow-Origin":"*"});x.pipe(res)
  });
  r.on("error",()=>{res.writeHead(502,{"Content-Type":"application/json"});res.end(JSON.stringify({error:"Java JDBC server is not running"}))});
  r.write(data);r.end()
 })}
function serve(req,res){
 let p=decodeURIComponent(req.url.split("?")[0]);if(p==="/")p="/index.html";
 const f=path.join(root,p);
 fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end("Page not found")}res.writeHead(200,{"Content-Type":types[path.extname(f)]||"text/plain"});res.end(d)})
}
http.createServer((req,res)=>req.url.startsWith("/api/")?proxy(req,res):serve(req,res)).listen(3000,()=>console.log("App: http://localhost:3000"));